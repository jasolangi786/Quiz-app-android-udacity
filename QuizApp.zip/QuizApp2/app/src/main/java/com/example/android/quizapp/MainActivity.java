package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int q1Score = 10;
    int q2Score = 10;
    int q3Score = 10;
    int q4Score = 10;
    int q5Score = 10;
    int q6Score = 10;

    int totalScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void submitResult(View view) {

        final RadioButton rightRadioBtn1 = (RadioButton) findViewById(R.id.quiz1_radio_check);
        final RadioButton wrongRadioBtn1 = (RadioButton) findViewById(R.id.quiz1_radio_check_2);
        final RadioButton rightRadioBtn2 = (RadioButton) findViewById(R.id.quiz2_radio_check);
        final RadioButton wrongRadioBtn2 = (RadioButton) findViewById(R.id.quiz2_radio_check_2);
        final RadioButton rightRadioBtn3 = (RadioButton) findViewById(R.id.quiz3_radio_check_2);
        final RadioButton wrongRadioBtn3 = (RadioButton) findViewById(R.id.quiz3_radio_check);
        final CheckBox rightCheckBoxQ41 = (CheckBox) findViewById(R.id.quiz4_radio_check_2);
        final CheckBox rightCheckBoxQ42 = (CheckBox) findViewById(R.id.quiz4_radio_check);
        final CheckBox wrongCheckBoxQ43 = (CheckBox) findViewById(R.id.quiz4_radio_check_3);

        final RadioButton rightRadioBtn5 = (RadioButton) findViewById(R.id.quiz5_radio_check);
        final RadioButton wrongRadioBtn5 = (RadioButton) findViewById(R.id.quiz5_radio_check_2);

        EditText answerIs = (EditText) findViewById(R.id.edit_question_field);
        String hardwareName = answerIs.getText().toString().toLowerCase();
        String answer = "keyboard";

        if (hardwareName.equals(answer)) {
            totalScore = totalScore + q1Score;
        }

        if (rightRadioBtn1.isChecked() && !wrongRadioBtn1.isChecked()) {
            totalScore = totalScore + q2Score;
        }

        if (rightRadioBtn2.isChecked() && !wrongRadioBtn2.isChecked()) {
            totalScore = totalScore + q3Score;

        }

        if (rightRadioBtn3.isChecked() && !wrongRadioBtn3.isChecked()) {
            totalScore = totalScore + q4Score;

        }

        if (rightCheckBoxQ41.isChecked() && rightCheckBoxQ42.isChecked() && !wrongCheckBoxQ43.isChecked()) {
            totalScore = totalScore + q5Score;

        }

        if (rightRadioBtn5.isChecked() && !wrongRadioBtn5.isChecked()) {
            totalScore = totalScore + q6Score;
            Toast.makeText(MainActivity.this, "Your score is :" + totalScore, Toast.LENGTH_SHORT).show();
            {
            }
        }
    }
}